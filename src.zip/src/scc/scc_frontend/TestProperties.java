package scc.scc_frontend;

public class TestProperties
{
	public static final String COSMOS_DB_ENDPOINT = "https://scc42997.documents.azure.com:443/";
	public static final String COSMOS_DB_MASTER_KEY = "O2qypn6EdITc60cmjXgpeGGnX49ohTiya3nQ3uWyqkdigVBtVH2Ikmi5uVXScGoiwbwisZFvucpONWQzW6DS0Q==";
	public static final String COSMOS_DB_DATABASE = "scc42997";

}
